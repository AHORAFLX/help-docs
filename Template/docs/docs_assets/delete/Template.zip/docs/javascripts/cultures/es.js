FH_CULTURES.es = {
    // FH Structural JS Translations
    copied: "Copiado en el portapapeles",
    filter_charts: "Filtrar gráficos",
    unfilter_charts: "Quitar filtro de los gráficos",
    flexygo_URL_modal_title: "Escribe aquí la URL de tu flexygo:",
    
    // Your JS translations here ↓
    
}