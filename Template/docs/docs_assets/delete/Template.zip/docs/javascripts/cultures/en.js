FH_CULTURES.en = {
    // FH Structural JS Translations
    copied: "Copied to clipboard", 
    filter_charts: "Filter charts",
    unfilter_charts: "Unfilter charts",
    flexygo_URL_modal_title: "Write here your flexygo\'s URL:",

    // Your JS translations here ↓
    
}